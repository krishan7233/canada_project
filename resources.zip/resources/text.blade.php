window.location.href ="https://greenberrysignature.co.in/policymarket/public/compare-quote?visitor_type="+data.visitor_type+"&visa_type="+data.visa_type+"&visitor_family_deductible="+data.visitor_family_deductible+"&visitor_family_policy_date1="+data.visitor_family_policy_date1+"&visitor_family_policy_year1="+data.visitor_family_policy_year1+"&visitor_family_policy_date2="+data.visitor_family_policy_date2+"&visitor_family_policy_year2="+data.visitor_family_policy_year2+"&visitor_family_start_date="+data.visitor_family_start_date+"&visitor_family_end_date="+data.visitor_family_end_date+"&visitor_family_days="+data.visitor_family_days+"&visitor_family_coverage_amt="+data.visitor_family_coverage_amt+"&visitor_family_exit="+data.visitor_family_exit+"&package="+commaSeparatedValues+"";

{{url('visitor-single-plan?visitor_type='.request('visitor_type').'&visa_type='.request('visa_type').'&visitor_family_deductible='.request('visitor_family_deductible').'&visitor_family_policy_date1='.request('visitor_family_policy_date1').'&visitor_family_policy_year1='.request('visitor_family_policy_year1').'&visitor_family_policy_date2='.request('visitor_family_policy_date2').'&visitor_family_policy_year2='.request('visitor_family_policy_year2').'&visitor_family_start_date='.request('visitor_family_start_date').'&visitor_family_end_date='.request('visitor_family_end_date').'&visitor_family_days='.request('visitor_family_days').''&visitor_family_coverage_amt='.request('visitor_family_coverage_amt').'&visitor_family_exit='.request('visitor_family_exit').'&buyer_id='.$compare['id'].'')}}

Array
(
    [visitor_type] => visitorFamily
    [visa_type] => visitorFamily
    [visitor_family_deductible] => 0
    [visitor_family_policy_date1] => null
    [visitor_family_policy_year1] => 35
    [visitor_family_policy_date2] => null
    [visitor_family_policy_year2] => 30
    [visitor_family_start_date] => 2024-02-11
    [visitor_family_end_date] => 2024-05-11
    [visitor_family_days] => 90
    [visitor_family_coverage_amt] => 100000
    [visitor_family_exit] => 0
    [package] => 10275, 6227
)
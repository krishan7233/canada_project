@extends('layout.commonlayout')
@section('content')
<!-- Form section start here -->
<div class="section-larger">
  <div class="container">
    <div class="row">
   <h1>Welcome In Visa Insurance </h1>
    </div>
  </div>
</div>
<!-- Form section Ends here -->
@endsection

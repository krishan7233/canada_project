<!-- Nav Bar Starts here -->
<div class="main-header">
<nav class="navbar fixed-top navbar-expand-lg">
  <div class="container">
    <div class="navbar-light">
      <!-- Logo -->
      <!--<a class="navbar-brand" href="#"> <img src="images/head_logo.png" alt=""> </a>-->
      <!-- Logo -->
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText"
               aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span> </button>
      <div class="collapse navbar-collapse" id="navbarText">
        <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
          <li class="nav-item active"> <a class="nav-link" href="#">Home</a> </li>
          <li class="nav-item"> <a class="nav-link" href="#">About Us</a> </li>
           <li class="nav-item"> <a class="nav-link" href="{{ route('super-visa') }}">Super Visa Insurance</a> </li>
          <li class="nav-item"> <a class="nav-link" href="#">Contact</a> </li>
        </ul>
       
      </div>
    </div>
  </div>
</nav>
</div>
<div class="clear-fix"></div>
<!-- Nav Bar Ends here -->
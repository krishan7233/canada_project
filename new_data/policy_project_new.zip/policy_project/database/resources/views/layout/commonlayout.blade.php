<!DOCTYPE html>
<html lang="zxx">
@include('layout.header')
<body>
<!-- Nav Bar Starts here -->

@include('layout.navigation')
 @yield('content')
<!-- Nav Bar Ends here -->
@include('layout.footer')
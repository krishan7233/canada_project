<?php $__env->startSection('content'); ?>

<!-- Form section start here -->
<div class="section-larger">
<?php  
if(Session::get('visitor_visa_request_data')){
  $request_data =  Session::get('visitor_visa_request_data');
 
}
if(Session::get('visitor_visa_deductible')){
  $deductible = Session::get('visitor_visa_deductible');
  
}


?>
<div class="container">
<?php echo $__env->make('layout.email_and_whatsapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php
if($deductible['pre_exit']==1){
  $exits_data = "covering pre-existing medical conditions";
}else{
  $exits_data = "excluding coverage for pre-existing medical conditions";
}

?>
  <div class="container mt-60">
    <div class="row">
      <div class="col-lg-4">
        <div class="quote-left">
          <p>Visitors to Canada Insurance for Single Person(age <?php echo e($request_data['age']); ?> years) for <?php echo e($request_data['no_of_days']); ?> days,  <?php echo e($exits_data); ?> <a href="<?php echo e(url('visitor-visa-insurance')); ?>"><span><i class="fa fa-pencil"></i></span></a></p>
          <div class="form-field-row">
            <div class="coverage"> <span>Deductible</span>
              <select class="form-control visitor-single-deductible-amt">
                <option value="0" <?php echo e($deductible['deductible'] == 0 ? 'selected' : ''); ?>>0</option>
                <option value="100" <?php echo e($deductible['deductible'] == 100 ? 'selected' : ''); ?>>100</option>
                <option value="250" <?php echo e($deductible['deductible'] == 250 ? 'selected' : ''); ?>>250</option>
                <option value="500" <?php echo e($deductible['deductible'] == 500 ? 'selected' : ''); ?>>500</option>
                <option value="1000" <?php echo e($deductible['deductible'] == 1000 ? 'selected' : ''); ?>>1000</option>
                <option value="2500" <?php echo e($deductible['deductible'] == 2500 ? 'selected' : ''); ?>>2500</option>
                <option value="5000" <?php echo e($deductible['deductible'] == 5000 ? 'selected' : ''); ?>>5000</option>
                <option value="10000" <?php echo e($deductible['deductible'] == 10000 ? 'selected' : ''); ?>>10000</option>
              </select>
            </div>
          </div>
          <div class="form-field-row">
            <div class="coverage"> <span>Coverage</span>
              <select class="form-control  visitor-single-coverage-amt">
              <option value="10000" <?php echo e($deductible['coverage_amt'] == 10000 ? 'selected' : ''); ?>>10,000</option>  
              <option value="15000" <?php echo e($deductible['coverage_amt'] == 15000 ? 'selected' : ''); ?>>15,000</option>
                <option value="20000" <?php echo e($deductible['coverage_amt'] == 20000 ? 'selected' : ''); ?>>20,000</option>
                <option value="25000" <?php echo e($deductible['coverage_amt'] == 25000 ? 'selected' : ''); ?>>25,000</option>
                <option value="30000" <?php echo e($deductible['coverage_amt'] == 30000 ? 'selected' : ''); ?>>30,000</option>
                <option value="50000" <?php echo e($deductible['coverage_amt'] == 50000 ? "selected" : (empty($deductible['coverage_amt']) ? "selected" :"")); ?>>50,000</option>
                <option value="100000" <?php echo e($deductible['coverage_amt'] == 100000 ? 'selected' : ''); ?>>100,000</option>
                <option value="150000" <?php echo e($deductible['coverage_amt'] == 150000 ? 'selected' : ''); ?>>150,000</option>
                <option value="200000" <?php echo e($deductible['coverage_amt'] == 200000 ? 'selected' : ''); ?>>200,000</option>
                <option value="250000" <?php echo e($deductible['coverage_amt'] == 250000 ? 'selected' : ''); ?>>250,000</option>
                <option value="300000" <?php echo e($deductible['coverage_amt'] == 300000 ? 'selected' : ''); ?>>300,000</option>
                <option value="500000" <?php echo e($deductible['coverage_amt'] == 500000 ? 'selected' : ''); ?>>500,000</option>
                <option value="1000000" <?php echo e($deductible['coverage_amt'] == 1000000 ? 'selected' : ''); ?>>1,000,000</option>
              </select>
            </div>
          </div>
          <h6>Would you like to cover pre-existing medical conditions?</h6>
          <div class="custom-control custom-radio custom-control-inline">
            <input type="radio" id="customRadioInline1" name="visitor_single_exit" class="custom-control-input" value="0" <?php echo e($deductible['pre_exit'] == 0 ? 'checked' : ''); ?>>
            <label class="custom-control-label" for="customRadioInline1">No</label>
          </div>
          <div class="custom-control custom-radio custom-control-inline">
            <input type="radio" id="customRadioInline2" name="visitor_single_exit" class="custom-control-input" value="1" <?php echo e($deductible['pre_exit'] == 1 ? 'checked' : ''); ?>>
            <label class="custom-control-label" for="customRadioInline2">Yes</label>
          </div>
        </div>
      </div>
      <div class="col-lg-8 quotation_data">
      <?php $__currentLoopData = $company_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $companies): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php
      if($companies->plan_type==1){
          $photo = $companies->basic;
          $compare_data = json_decode($companies->compare_basic,true);
        }
        if($companies->plan_type==2){
          $photo = $companies->standard;
          $compare_data = json_decode($companies->compare_standard,true);

        }
        if($companies->plan_type==3){
          $photo = $companies->enhanced;
          $compare_data = json_decode($companies->compare_enhanced,true);

        }
        ?>
        <div class="quote-right">
          <div class="quote-box">
            <div class="logo-section"> <img src="<?php echo e($photo); ?>" /> </div>
            <div class="price-section">
              <h3><?php echo e('$'.number_format($companies->total_charge - $companies->detect_amt, 2)); ?></h3>
              <!-- <h3><span><strong><?php echo e('$'.$companies->per_month); ?></strong>/month</span></h3> -->
              <h3><span>Deductible <strong><?php echo e($companies->deductible_amt); ?></strong> 
              <?php if ($companies->company_id == 4 || $companies->company_id == 11 || $companies->company_id == 10 || $companies->company_id == 7) { 
                if($companies->company_id == 4 && $companies->plan_type==1){
                  echo "per claim";
                }else{
                  echo "per policy";
                }
                } 
              else { echo "per claim"; } ?>
            
            </span></h3>
            </div>
            <div class="btn-section"> <a href="<?php echo e(url('visitor-single-plan',$companies->id)); ?>" target="_blank" class="buy-now">BUY NOW</a> 
            <a href="#" class="plan-details toggle togglePlanDetails" id="toggle" onclick="togglePlanDetails_<?php echo e($companies->id); ?>(<?php echo e($companies->id); ?>)">PLAN DETAILS</a>
            <button class="btn btn-primary visitor_visa_compareData" id="visitor_visa_compare_btn_<?php echo e($companies->id); ?>" style="display:none;">COMPARE</button>

<div class="compaire">
                <div class="left">
                  <input type="checkbox" class="form-check-input visitor_single_compare" id="visitor_single_compare" value="<?php echo e($companies->id); ?>">
                  <label class="form-check-label" for="visitor_single_compare">Compare</label>
                </div>
                <div class="right"> <a href="<?php echo e(url('visitor-single-plan',$companies->id)); ?>">Benefit Summary</a> </div>
              </div>
            </div>
          </div>
          <div id="text<?php echo e($companies->id); ?>" style="display:none;" class="hidden-plan-details">
            <div class="row">
              <div class="col-lg-4">
                <div class="section1">
                  <h4>Summary</h4>
                  <p>Coverage: <?php echo e($companies->aggregate_price); ?></p>
                  <p> Deductible: <?php echo e($companies->deductible_amt); ?></p>
                  <p>Period: <?php echo e($companies->no_of_days); ?> days</p>
                  <p> Pre-existing medical conditions: <b><?php echo e($companies->pre_exit); ?></b> covered</p>
                </div>
              </div>
              <div class="col-lg-4">
                <div class="section2">
                <ul>
                    <li>Hospitalization(Related to Emergency):-<strong><?php echo e($compare_data['hospitalization_related_to_emergency']); ?></strong></li>
                    <li> Covid-19:-<strong><?php echo e($compare_data['covid_19']); ?></strong></li>
                    <li> Ambulance:-<strong><?php echo e($compare_data['ambulance']); ?></strong></li>
                    <li> Walk-in Clinic Visit:-<strong><?php echo e($compare_data['walk_in_clinic_visits']); ?></strong></li>
                    <li> Prescriptions(Related to Emergencies):-<strong><?php echo e($compare_data['prescriptions_related_to_emergencies']); ?></strong></li>
                    <li>Dental Pain Relief:- <strong><?php echo e($compare_data['dental_pain_relief']); ?></strong></li>
                    <li> Side Trips:-<strong><?php echo e($compare_data['trip_break_benefit']); ?></strong> </li>
                  </ul>
                  <p><em>*Important notice:   The above is only a Summary of Benefits; for complete details, refer to <a href="#">Policy Wording.</a></em></p>
                </div>
              </div>
              <div class="col-lg-4">
                <div class="section3"> <a href="tel:6475709070" class="call-btn"><i class="fa fa-mobile"></i> (647) 570-9070</a> <a href="<?php echo e(url('visitor-single-plan',$companies->id)); ?>" class="benifit-sumry" target="_blank">Benefit Summary</a> <a href="<?php echo e(url('visitor-single-plan',$companies->id)); ?>" target="_blank" class="srt-app">Start Application</a> </div>
              </div>
            </div>
          </div>
        </div>
        <script>
          function togglePlanDetails_<?php echo e($companies->id); ?>(id) {
            $('#text' + id).toggle();  // Assuming 'id' is a variable containing the desired ID

          }
        </script>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      <div class="col-lg-8 quotation_filter_data"></div>
    </div>
  </div>
</div>
<!-- Form section Ends here -->

<script>
  $(document).ready(function() {
    var values = [];

    $(".visitor_single_compare").change(function() {
        var checkedCheckboxes = $(".visitor_single_compare:checked");
        var count = checkedCheckboxes.length;
        // alert(count);
        values = [];

        if (count >= 2) {
            checkedCheckboxes.each(function() {
                var value = $(this).val();
                if (!values.includes(value)) {
                    values.push(value);
                }
                $('#visitor_visa_compare_btn_' + value).show();
            });

            // Hide any comparison buttons that are not associated with checked checkboxes
            $('[id^="visitor_visa_compare_btn_"]').each(function() {
                if (!values.includes($(this).attr("id").replace("visitor_visa_compare_btn_", ""))) {
                    $(this).hide();
                }
            });
        }
        else {
            // If there are fewer than two checkboxes checked, hide all comparison buttons.
            $('[id^="visitor_visa_compare_btn_"]').hide();
        }
    });

    $('.visitor_visa_compareData').click(function() {
      var csrfToken = $('meta[name="csrf-token"]').attr('content');

        var commaSeparatedValues = values.join(', ');
        $.ajax({
          type: 'POST',
          url: 'visitor-single-compare-post',  // Replace with your controller URL
          data: {
            compare_data: commaSeparatedValues,
          },
          headers: {
            'X-CSRF-TOKEN': csrfToken
          },
          success: function(response) {
            // console.log(response);
            window.location.href = 'visitor-single-compare';
          },
          error: function(jqXHR, textStatus, errorThrown) {
            console.error('AJAX request failed:', textStatus, errorThrown);
          }
        });
    });
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.commonlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\policy_project\resources\views/visitor-single-quotation.blade.php ENDPATH**/ ?>
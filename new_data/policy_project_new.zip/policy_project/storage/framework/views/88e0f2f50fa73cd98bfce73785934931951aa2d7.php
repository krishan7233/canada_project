<div class="row">
    	<div class="col-lg-12">
        	<div class="get-email">
            	<a href="#" id="EmailBtn">Email/Text these rates</a>
            </div>
			
			<div class="emailData" id="HiddnData">
				<a href="#" class="CloseBtn" id="DismissBtn"> <i class="fa fa-close"></i> </a>
			<h3>Get an Email/Text</h3>
				<form action="<?php echo e(url('email-and-whatsapp-post')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <div class="row">
                        <div class="col-lg-4">
                            <div class="form-group">
                            <input type="text" class="form-control"  placeholder="Your Name" name="name">
                        </div>
                        </div>
                        
                        <div class="col-lg-4">
                            <div class="form-group">
                            <input type="email" class="form-control"  placeholder="Email" name="email" required>
                        </div>
                        </div>
                        
                        <div class="col-lg-4">
                            <div class="form-group">
                            <input type="text" class="form-control" id="myInput" placeholder="Canadian Phone" name="mobile">
                            <span>Canadian Phone number only.</span>
                        </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12 text-center">
                            <!-- <input type="submit" class="SendBtn" value="EMAIL/TEXT"> -->
                            <button class="SendBtn" value="1" name="send_type">EMAIL/TEXT</button>
                           
                            <a href="#" class="SendBtn" id="WhtsBtn" style="display: none">WHATSAPP</a>
                        </div>
                    </div>
		        </form>
			</div>
			
        </div>
    </div><?php /**PATH C:\xampp\htdocs\policy_project\resources\views/layout/email_and_whatsapp.blade.php ENDPATH**/ ?>